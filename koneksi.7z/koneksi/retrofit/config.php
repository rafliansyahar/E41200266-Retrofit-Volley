<?php

$host = "localhost";
$user = "root";
$password = "";
$db   = "workshop_mobile";

$conn = mysqli_connect($host, $user, $password, $db) or die("Gagal menghubungi server!");;

?>